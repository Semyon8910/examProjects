import "./Ofir.css";

function Ofir(): JSX.Element {
    return (
        <div className="Ofir">
			<div className="Box">
                I'm the king of the world !!!
            </div>
        </div>
    );
}

export default Ofir;
