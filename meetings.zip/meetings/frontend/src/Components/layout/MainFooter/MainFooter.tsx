import "./MainFooter.css";

function MainFooter(): JSX.Element {
    return (
        <div className="MainFooter">
			
        </div>
    );
}

export default MainFooter;
