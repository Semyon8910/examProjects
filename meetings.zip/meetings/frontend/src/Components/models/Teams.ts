export class Team {
    teamID: number;
    team_name: string;

    constructor (teamID: number, team_name: string) {
        this.teamID=teamID;
        this.team_name=team_name;
    }
}