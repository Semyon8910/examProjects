import "./Page404.css";

export function Page404(): JSX.Element {
    return (
        <div className="Page404">
			<h1>Oops i did it again......</h1>
        </div>
    );
}
